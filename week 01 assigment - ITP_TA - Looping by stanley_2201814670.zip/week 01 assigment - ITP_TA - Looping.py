# this code is used for triangle-shaped looping on top-right side.
for x in range(0,10):
    for z in range(0,x+1):
        print(" ",end=" ")
    for y in range(0,10-x):
        print("*",end=" ")
    print()
# this code is used for triangle-shaped looping on center side.
for a in range (1,11):
    for b in range(1,11-a):
        print(" ",end="")
    for c in range(a*2-1,0,-1):
        print("*",end="")
    print()
#this code is used for diamond-shaped looping.
for d in range (1,11):
    for e in range(1,11-d):
        print(" ",end="")
    for f in range(d*2-1,0,-1):
        print("*",end="")
    print()
for d in range (1,10):
    for e in range(1,d+1):
        print(" ",end="")
    for f in range((10*2-1)-d*2,0,-1):
        print("*",end="")
    print()
